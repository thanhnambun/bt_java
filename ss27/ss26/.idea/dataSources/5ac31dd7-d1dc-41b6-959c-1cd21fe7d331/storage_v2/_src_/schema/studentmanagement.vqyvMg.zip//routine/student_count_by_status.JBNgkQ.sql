create
    definer = root@localhost procedure student_count_by_status(IN status_in bit, OUT ctn_student int)
begin
    select count(student.student_id) into ctn_student from student where student_status=status_in;
end;

