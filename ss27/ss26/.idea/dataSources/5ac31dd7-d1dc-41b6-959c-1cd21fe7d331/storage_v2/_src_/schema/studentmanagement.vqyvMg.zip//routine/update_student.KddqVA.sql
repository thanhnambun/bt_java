create
    definer = root@localhost procedure update_student(IN id_in int, IN name_in varchar(255), IN age_in int, IN status_in bit)
begin
    update  student
        set student_name = name_in,
            student_age = age_in,
            student_status = status_in
    where student_id = id_in;
end;

