create
    definer = root@localhost procedure create_student(IN id_in int, IN name_in varchar(255), IN status_in bit)
begin
   insert into student(student_id, student_name, student_status)
       VALUE(id_in,name_in,status_in);
end;

