create
    definer = root@localhost procedure delete_student(IN id_in int)
begin
    delete from student where student_id = id_in;
end;

